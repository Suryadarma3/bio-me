export { default as NowPlaying } from "./Misc/NowPlaying.misc";

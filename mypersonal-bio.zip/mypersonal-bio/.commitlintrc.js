module.exports = {extends: ['gitmoji']};
